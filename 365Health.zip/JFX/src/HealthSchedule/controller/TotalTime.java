package HealthSchedule.controller;

public class TotalTime {

	String everyday;
	int totalTimehour;
	int totalTimeminute;
	int totalTimesecond;
	public String getEveryday() {
		return everyday;
	}
	public void setEveryday(String everyday) {
		this.everyday = everyday;
	}
	public int getTotalTimehour() {
		return totalTimehour;
	}
	public void setTotalTimehour(int totalTimehour) {
		this.totalTimehour = totalTimehour;
	}
	public int getTotalTimeminute() {
		return totalTimeminute;
	}
	public void setTotalTimeminute(int totalTimeminute) {
		this.totalTimeminute = totalTimeminute;
	}
	public int getTotalTimesecond() {
		return totalTimesecond;
	}
	public void setTotalTimesecond(int totalTimesecond) {
		this.totalTimesecond = totalTimesecond;
	}
	
}

package HealthSchedule.controller;

public class Routines_lower {

	String everyday;
	String bodypart;
	String videoname;
	
	public String getEveryday() {
		return everyday;
	}
	public void setEveryday(String everyday) {
		this.everyday = everyday;
	}
	public String getBodypart() {
		return bodypart;
	}
	public void setBodypart(String bodypart) {
		this.bodypart = bodypart;
	}
	public String getVideoname() {
		return videoname;
	}
	public void setVideoname(String videoname) {
		this.videoname = videoname;
	}
	
	
}

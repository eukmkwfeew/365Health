package HealthSchedule.Interface;

import HealthSchedule.model.Food;

public interface FoodTableListener {
	public void onClickListener(Food food);
}

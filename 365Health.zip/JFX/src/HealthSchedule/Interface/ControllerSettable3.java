package HealthSchedule.Interface;

import javafx.fxml.Initializable;

public interface ControllerSettable3 {

	void setController3(Initializable controller);

	

}

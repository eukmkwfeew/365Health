package HealthSchedule.Interface;

import javafx.fxml.Initializable;

public interface ControllerSettable {

	void setController(Initializable controller);
//	void setController1(Initializable controller);
	

}

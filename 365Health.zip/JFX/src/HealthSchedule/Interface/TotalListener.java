package HealthSchedule.Interface;

import HealthSchedule.model.Routines;

public interface TotalListener {
	public void onClickListener(Routines routine);
}

package HealthSchedule.Interface;

import javafx.fxml.Initializable;

public interface ControllerSettable2 {

	void setController2(Initializable controller);

	

}

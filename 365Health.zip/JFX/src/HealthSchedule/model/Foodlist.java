package HealthSchedule.model;

public class Foodlist {
   
   String everyday, eattime, foodname, foodunit, cal;
   

   public String getEveryday() {
      return everyday;
   }

   public void setEveryday(String everyday) {
      this.everyday = everyday;
   }

   public String getEattime() {
      return eattime;
   }

   public void setEattime(String eattime) {
      this.eattime = eattime;
   }

   public String getFoodname() {
      return foodname;
   }

   public void setFoodname(String foodname) {
      this.foodname = foodname;
   }

   public String getFoodunit() {
      return foodunit;
   }

   public void setFoodunit(String foodunit) {
      this.foodunit = foodunit;
   }

   public String getCal() {
      return cal;
   }

   public void setCal(String cal) {
      this.cal = cal;
   }

}
package HealthSchedule.model;

public class Memo {

	private String everyday;
	private String title;
	private String content;
	
	public void setEveryday(String everyday) {
		this.everyday = everyday;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getEveryday() {
		return everyday;
	}
	public String getTitle() {
		return title;
	}
	public String getContent() {
		return content;
	}
	
}

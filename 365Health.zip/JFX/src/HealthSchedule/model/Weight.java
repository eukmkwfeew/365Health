package HealthSchedule.model;

public class Weight {

	private String everyday;
	private double weight;
	
	public String getEveryday() {
		return everyday;
	}
	public void setEveryday(String everyday) {
		this.everyday = everyday;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
}

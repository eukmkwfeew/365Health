package HealthSchedule.model;

public class FoodTable {
	String  foodname, foodunit, cal;
	   

	 

	   public String getFoodname() {
	      return foodname;
	   }

	   public void setFoodname(String foodname) {
	      this.foodname = foodname;
	   }

	   public String getFoodunit() {
	      return foodunit;
	   }

	   public void setFoodunit(String foodunit) {
	      this.foodunit = foodunit;
	   }

	   public String getCal() {
	      return cal;
	   }

	   public void setCal(String cal) {
	      this.cal = cal;
	   }

}
